var files =
[
    [ "Bottin.cpp", "_bottin_8cpp.html", null ],
    [ "Bottin.h", "_bottin_8h.html", "_bottin_8h" ],
    [ "Principal.cpp", "_principal_8cpp.html", "_principal_8cpp" ]
];